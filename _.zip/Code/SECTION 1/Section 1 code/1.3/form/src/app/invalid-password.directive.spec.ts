import { InvalidPasswordDirective } from './invalid-password.directive';

describe('InvalidPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new InvalidPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
